<!doctype html>
<html>

<head>
    <title>My Layout</title>
</head>

<body>
    <?= $this->renderSection('content') ?>
</body>

</html>