<?= $this->extend('layouts2/default') ?>

<?= $this->section('content'); ?>

<h1>This is my about page</h1>

<?= $this->endSection('content'); ?>