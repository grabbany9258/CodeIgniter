<?php echo view('includes/header'); ?>
<?php echo view('includes/navbar'); ?>

<div class="container">

    <h1>This is my contact us page</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Delectus minus beatae ullam. Asperiores, nulla eligendi deserunt aliquid consequatur officia nemo necessitatibus quae, dolorum, magni numquam modi. Nulla sed voluptate reprehenderit!</p>
</div>
<?php echo view('includes/footer'); ?>