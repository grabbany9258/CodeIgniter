<?php echo view('includes/header'); ?>
<?php echo view('includes/navbar'); ?>

<div class="container">
    <h1>About us </h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt maiores consectetur optio enim doloremque dicta corporis impedit nihil molestiae! Omnis deserunt amet molestias, quo sequi inventore minima laborum consectetur quod.</p>


</div>
<?php echo view('includes/footer'); ?>