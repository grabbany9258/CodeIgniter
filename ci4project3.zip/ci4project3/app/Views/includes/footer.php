<div class="mt-5 p-4 bg-dark text-white text-center">
    <p>Footer</p>
</div>

</body>

</html>